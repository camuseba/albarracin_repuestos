// ==========================================
// VEHICLE MODELS DATABASE MAP
// ==========================================
const VEHICLE_MODELS_MAP = {
  Honda: ["CG Titan 150", "XR 250 Tornado"],
  Yamaha: ["YZF-R3"],
  Motomel: ["Blitz 110"],
  Corven: ["Triax 150"],
  Toyota: ["Hilux"],
  Volkswagen: ["Gol Trend", "Voyage", "Fox"],
  Chevrolet: ["Corsa", "Classic"]
};

// ==========================================
// LOCAL DATABASE: REALISTIC INVENTORY WITH COMPATIBILITIES
// ==========================================
const PRODUCTS_DATA = [
  // MOTOS
  {
    id: 1,
    name: "Honda XR 250 Tornado 0km",
    category: "motos",
    subcategory: "motos",
    price: 4800000,
    brand: "Honda",
    img: "assets/moto_honda_xr.jpg",
    desc: "Moto de enduro legendaria, ideal para ciudad y terrenos mixtos. Arranque eléctrico, motor de 4 tiempos DOHC y caja de 6 velocidades. Confiabilidad absoluta.",
    specs: {
      "Año": "2026",
      "Motor": "249cc DOHC Monocilíndrico",
      "Potencia": "23 HP a 7500 RPM",
      "Frenos": "Disco delantero hidráulico, tambor trasero",
      "Transmisión": "6 marchas manual"
    },
    promo: true,
    oldPrice: 5100000,
    compatibilities: [
      { brand: "Honda", model: "XR 250 Tornado", yearStart: 2010, yearEnd: 2026 }
    ],
  },
  {
    id: 2,
    name: "Yamaha YZF-R3 ABS Usada (2022)",
    category: "motos",
    subcategory: "motos",
    price: 6200000,
    brand: "Yamaha",
    img: "assets/moto_yamaha_r3.jpg",
    desc: "Deportiva en impecable estado general, único dueño. Services al día realizados en concesionaria oficial. Cubiertas nuevas y frenos ABS de doble canal.",
    specs: {
      "Año": "2022",
      "Kilometraje": "14.200 km",
      "Motor": "321cc bicilíndrico DOHC",
      "Refrigeración": "Líquida",
      "Frenos": "Discos con ABS delanteros y traseros"
    },
    promo: false,
    compatibilities: [
      { brand: "Yamaha", model: "YZF-R3", yearStart: 2015, yearEnd: 2026 }
    ],
  },
  {
    id: 3,
    name: "Motomel Blitz 110 V8 0km",
    category: "motos",
    subcategory: "motos",
    price: 1100000,
    brand: "Motomel",
    img: "assets/moto_motomel_blitz.jpg",
    desc: "La motocicleta CUB más vendida del país. Ideal para traslados diarios y trabajo urbano por su consumo sumamente bajo, gran agilidad y durabilidad.",
    specs: {
      "Año": "2026",
      "Motor": "110cc monocilíndrico de 4 tiempos",
      "Transmisión": "Semiautomática de 4 velocidades",
      "Capacidad Tanque": "3.8 Litros",
      "Consumo promedio": "2.1 L / 100 km"
    },
    promo: true,
    oldPrice: 1250000,
    compatibilities: [
      { brand: "Motomel", model: "Blitz 110", yearStart: 2012, yearEnd: 2026 }
    ],
  },
  {
    id: 4,
    name: "Corven Triax 150 0km",
    category: "motos",
    subcategory: "motos",
    price: 1850000,
    brand: "Corven",
    img: "assets/moto_corven_triax.jpg",
    desc: "Moto on-off ideal para sortear terrenos irregulares. Equipada con portaequipaje trasero de aluminio, excelente despeje del suelo y amortiguación de gran recorrido.",
    specs: {
      "Año": "2026",
      "Motor": "149cc monocilíndrico de 4 tiempos",
      "Arranque": "Eléctrico y por patada",
      "Suspensión": "Horquilla telescópica / Monoamortiguador"
    },
    promo: false,
    compatibilities: [
      { brand: "Corven", model: "Triax 150", yearStart: 2014, yearEnd: 2026 }
    ],
  },

  // REPUESTOS
  {
    id: 5,
    name: "Kit de Transmisión DID CG Titan 150",
    category: "repuestos",
    subcategory: "motos",
    price: 32000,
    brand: "DID",
    img: "assets/repuesto_kit_did.jpg",
    desc: "Kit de transmisión de la más alta calidad compuesto por cadena, corona y piñón. Máxima durabilidad en condiciones de alta exigencia de torque.",
    specs: {
      "Origen": "Japón",
      "Cadena": "428H x 118L",
      "Corona": "43 dientes reforzados",
      "Piñón": "16 dientes",
      "Compatibilidad": "Honda CG Titan 150 / Honda Invicta"
    },
    promo: true,
    oldPrice: 38000,
    compatibilities: [
      { brand: "Honda", model: "CG Titan 150", yearStart: 2005, yearEnd: 2026 }
    ],
  },
  {
    id: 6,
    name: "Pastillas de Freno Delanteras Fras-le Hilux",
    category: "repuestos",
    subcategory: "pickups",
    price: 34500,
    brand: "Fras-le",
    img: "assets/repuesto_pastillas_cobreq.jpg",
    desc: "Pastillas de freno delanteras fabricadas con compuestos libres de asbesto. Garantizan un frenado seguro, estable y de bajo nivel de ruido para pickups exigidas.",
    specs: {
      "Posición": "Delantera",
      "Material": "Semimetálico Premium",
      "Compatibilidad": "Toyota Hilux (2005 - 2015) 4x2 y 4x4",
      "Origen": "Brasil"
    },
    promo: false,
    compatibilities: [
      { brand: "Toyota", model: "Hilux", yearStart: 2005, yearEnd: 2015 }
    ],
  },
  {
    id: 7,
    name: "Cubierta Pirelli Super City 2.75-18",
    category: "repuestos",
    subcategory: "motos",
    price: 42000,
    brand: "Pirelli",
    img: "assets/repuesto_cubierta_pirelli.jpg",
    desc: "Neumático diseñado para motocicletas urbanas de baja y media cilindrada. Excelente comportamiento en superficies mojadas y gran rendimiento kilométrico.",
    specs: {
      "Medidas": "2.75-18 (Uso delantero/trasero)",
      "Índice de carga/vel": "42P (150 kg / 150 km/h)",
      "Origen": "Brasil"
    },
    promo: false,
    compatibilities: [
      { brand: "Honda", model: "CG Titan 150", yearStart: 2005, yearEnd: 2026 },
      { brand: "Motomel", model: "Blitz 110", yearStart: 2010, yearEnd: 2026 }
    ],
  },
  {
    id: 8,
    name: "Correa de Distribución Gates Chevrolet Corsa",
    category: "repuestos",
    subcategory: "autos",
    price: 12500,
    brand: "Gates",
    img: "assets/repuesto_correa_gates.jpg",
    desc: "Correa dentada de alto rendimiento fabricada en compuesto de caucho altamente resistente a altas temperaturas y fricción continua.",
    specs: {
      "Compatibilidad": "Chevrolet Corsa / Classic / Fun / Agile 1.4 y 1.6 8V",
      "Material": "Cloropreno reforzado",
      "Código de pieza": "5409XS"
    },
    promo: false,
    compatibilities: [
      { brand: "Chevrolet", model: "Corsa", yearStart: 1996, yearEnd: 2016 },
      { brand: "Chevrolet", model: "Classic", yearStart: 2010, yearEnd: 2016 }
    ],
  },
  {
    id: 9,
    name: "Filtro de Aire Mann Filter Gol Trend",
    category: "repuestos",
    subcategory: "autos",
    price: 15800,
    brand: "Mann Filter",
    img: "assets/repuesto_filtro_mann.jpg",
    desc: "Filtro de aire de alta performance. Retiene hasta el 99.8% de las impurezas del aire de admisión del motor, garantizando una combustión óptima y limpia.",
    specs: {
      "Compatibilidad": "Gol Trend / Voyage / Fox / Suran 1.6 8V",
      "Código de pieza": "C30005",
      "Material": "Celulosa premium plisada"
    },
    promo: true,
    oldPrice: 19000,
    compatibilities: [
      { brand: "Volkswagen", model: "Gol Trend", yearStart: 2008, yearEnd: 2020 },
      { brand: "Volkswagen", model: "Voyage", yearStart: 2008, yearEnd: 2020 },
      { brand: "Volkswagen", model: "Fox", yearStart: 2005, yearEnd: 2020 }
    ],
  },
  {
    id: 10,
    name: "Amortiguador Corven Plus Delantero Toyota Hilux",
    category: "repuestos",
    subcategory: "pickups",
    price: 78000,
    brand: "Corven",
    img: "assets/repuesto_amortiguador_corven.jpg",
    desc: "Amortiguador hidráulico presurizado a gas. Mejora notablemente la estabilidad de la pickup, control de rolido y confort de marcha en caminos rotos.",
    specs: {
      "Posición": "Delantero",
      "Lado": "Izquierdo / Derecho",
      "Tecnología": "Presurizado a Gas Nitrógeno",
      "Compatibilidad": "Toyota Hilux 4x4 / 4x2 2005 a 2015"
    },
    promo: false,
    compatibilities: [
      { brand: "Toyota", model: "Hilux", yearStart: 2005, yearEnd: 2015 }
    ],
  },

  // VIGIA VIESA (Considered Universal for Camiones/All vehicles unless filtered)
  {
    id: 11,
    name: "Climatizador Ecológico VIESA Intelligent v11",
    category: "vigia-viesa",
    subcategory: "camiones",
    price: 780000,
    brand: "Viesa",
    img: "assets/equip_viesa_intelligent.jpg",
    desc: "Climatizador ecológico que enfría la cabina del camión mediante la evaporación de agua. Trabaja directamente con la batería a 12V/24V y funciona perfectamente con el motor apagado sin consumir combustible.",
    specs: {
      "Voltaje": "12V y 24V",
      "Consumo de agua": "0.5 a 1.5 litros por hora",
      "Consumo eléctrico": "0.5 a 4 Amperios",
      "Protección de batería": "Apagado automático ante baja tensión",
      "Instalación": "Servicio Oficial Albarracín Incluido"
    },
    promo: true,
    oldPrice: 850000,
    compatibilities: [], // Universal
  },
  {
    id: 12,
    name: "Protector de Motor VIGIA 500 Calibrador Interno",
    category: "vigia-viesa",
    subcategory: "camiones",
    price: 490000,
    brand: "Vigia",
    img: "assets/equip_vigia_protector.jpg",
    desc: "El protector de motor automático Vigia monitorea de forma permanente la presión de aceite y la temperatura del motor de tu camión, auto o maquinaria agrícola. Ante un desperfecto grave, corta el motor previniendo fundidas.",
    specs: {
      "Modelo": "Vigia Serie 500",
      "Sensores": "Temperatura de agua / Presión de aceite",
      "Alerta": "Indicadores LED audibles y corte automático",
      "Instalación": "Taller Oficial Homologado"
    },
    promo: false,
    compatibilities: [], // Universal
  },
  {
    id: 13,
    name: "Vigia Sistema de Calibración de Neumáticos - Camión",
    category: "vigia-viesa",
    subcategory: "camiones",
    price: 1200000,
    brand: "Vigia",
    img: "assets/equip_vigia_calibrador.jpg",
    desc: "Sistema automático que mantiene de forma constante e inteligente la presión predeterminada de los neumáticos del camión y acoplado. En caso de pinchadura, sigue inflando y emite alerta lumínica para llegar a destino.",
    specs: {
      "Aplicación": "Camiones y Acoplados de 2 a 3 ejes",
      "Presión nominal": "Regulable según carga de neumáticos",
      "Funcionamiento": "Compresor de aire central del camión"
    },
    promo: false,
    compatibilities: [], // Universal
  },

  // ELECTRICIDAD & ALARMAS
  {
    id: 14,
    name: "Alarma PST Positron PX360 BT",
    category: "electricidad-alarmas",
    subcategory: "autos",
    price: 85000,
    brand: "PST Positron",
    img: "assets/alarma_pst_px360.jpg",
    desc: "Alarma volumétrica para automóviles de última generación. Posee control por presencia (corte de motor a distancia) y conectividad Bluetooth para manejar la alarma directamente desde tu celular mediante aplicación.",
    specs: {
      "Conectividad": "Bluetooth (Android / iOS)",
      "Funciones": "Presencia, volumétrico, pánico, trabapuertas",
      "Controles": "2 controles incluidos (1 de presencia)",
      "Garantía": "2 Años de Fábrica"
    },
    promo: true,
    oldPrice: 98000,
    compatibilities: [], // Universal para autos
  },
  {
    id: 15,
    name: "Batería Moura 12V 75Ah M26AD",
    category: "electricidad-alarmas",
    subcategory: "autos",
    price: 165000,
    brand: "Moura",
    img: "assets/bateria_moura_75.jpg",
    desc: "Batería Moura de aleación Plata-Calcio libre de mantenimiento. Excelente entrega de energía en arranques fríos extremos. Ideal para vehículos modernos con equipamiento electrónico avanzado y pick-ups.",
    specs: {
      "Capacidad": "75 Ah (C20)",
      "Voltaje": "12 Volts",
      "CCA (Arranque frío)": "620 A",
      "Borne": "Derecho (+)",
      "Dimensiones": "282 x 175 x 190 mm"
    },
    promo: false,
    compatibilities: [
      { brand: "Toyota", model: "Hilux", yearStart: 2005, yearEnd: 2026 },
      { brand: "Volkswagen", model: "Gol Trend", yearStart: 2008, yearEnd: 2026 },
      { brand: "Chevrolet", model: "Corsa", yearStart: 1996, yearEnd: 2016 }
    ],
  },
  {
    id: 16,
    name: "Alarma para Moto PST Positron FX360",
    category: "electricidad-alarmas",
    subcategory: "motos",
    price: 54000,
    brand: "PST Positron",
    img: "assets/alarma_pst_fx360.jpg",
    desc: "Alarma de presencia antirrobo para motos. Equipada con acelerómetro integrado para registrar movimientos extraños en la moto inclinada o movida. Consumo mínimo de corriente para cuidar la batería de la moto.",
    specs: {
      "Sensor": "Acelerómetro de 3 ejes",
      "Controles": "2 controles de presencia",
      " Sirena": "Piezoeléctrica de alto volumen",
      "Consumo": "Menor a 1.5 mA"
    },
    promo: false,
    compatibilities: [], // Universal para motos
  }
];

// ==========================================
// STATE MANAGEMENT
// ==========================================
const state = {
  cart: [],
  filters: {
    category: "todos",
    vehicle: "todos",
    priceMin: null,
    priceMax: null,
    brand: "todas",
    search: "",
    // Compatibility Checker state
    compBrand: "",
    compModel: "",
    compYear: ""
  },
  sorting: "relevancia",
  theme: "dark"
};

// ==========================================
// INITIALIZATION
// ==========================================
document.addEventListener("DOMContentLoaded", () => {
  initTheme();
  loadCartFromStorage();
  initNavScroll();
  initRevealAnimations();
  initCategoryCards();
  
  // Render Filters sidebar dynamic brands
  renderBrandFilters();

  // Render Catalog
  renderCatalog();

  // Bind UI Events
  bindUIEvents();
  
  // Init Compatibility Dropdowns
  initCompatibilityWidget();
});

// ==========================================
// THEME MANAGER
// ==========================================
function initTheme() {
  const savedTheme = localStorage.getItem("albarracin-theme");
  const systemTheme = window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
  
  state.theme = savedTheme || systemTheme;
  document.documentElement.setAttribute("data-theme", state.theme);
  
  updateThemeIcon();
}

function toggleTheme() {
  state.theme = state.theme === "dark" ? "light" : "dark";
  document.documentElement.setAttribute("data-theme", state.theme);
  localStorage.setItem("albarracin-theme", state.theme);
  updateThemeIcon();
}

function updateThemeIcon() {
  const sunIcon = document.querySelector(".sun-icon");
  const moonIcon = document.querySelector(".moon-icon");
  
  if (state.theme === "dark") {
    sunIcon.style.display = "block";
    moonIcon.style.display = "none";
  } else {
    sunIcon.style.display = "none";
    moonIcon.style.display = "block";
  }
}

// ==========================================
// SCROLL & REVEAL ANIMATIONS
// ==========================================
function initNavScroll() {
  const header = document.getElementById("main-header");
  const navLinks = document.querySelectorAll(".nav-link");
  const sections = document.querySelectorAll("section");

  window.addEventListener("scroll", () => {
    if (window.scrollY > 50) {
      header.classList.add("scrolled");
    } else {
      header.classList.remove("scrolled");
    }

    let currentSectionId = "";
    sections.forEach(sec => {
      const secTop = sec.offsetTop - 120;
      const secHeight = sec.clientHeight;
      if (window.scrollY >= secTop && window.scrollY < secTop + secHeight) {
        currentSectionId = sec.getAttribute("id");
      }
    });

    if (currentSectionId) {
      navLinks.forEach(link => {
        link.classList.remove("active");
        if (link.getAttribute("href") === `#${currentSectionId}`) {
          link.classList.add("active");
        }
      });
    }
  });

  const mobileToggle = document.getElementById("mobile-toggle");
  const navMenu = document.getElementById("nav-menu");

  mobileToggle.addEventListener("click", () => {
    navMenu.classList.toggle("open");
    mobileToggle.classList.toggle("active");
  });

  navLinks.forEach(link => {
    link.addEventListener("click", () => {
      navMenu.classList.remove("open");
      mobileToggle.classList.remove("active");
    });
  });
}

function initRevealAnimations() {
  const revealElements = document.querySelectorAll(".reveal");
  
  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("active");
        revealObserver.unobserve(entry.target);
      }
    });
  }, {
    threshold: 0.1,
    rootMargin: "0px 0px -50px 0px"
  });

  revealElements.forEach(el => revealObserver.observe(el));
}

function initCategoryCards() {
  const categoryCards = document.querySelectorAll(".category-card");
  categoryCards.forEach(card => {
    card.addEventListener("click", () => {
      const category = card.getAttribute("data-category");
      setCatalogCategory(category);
      document.getElementById("catalogo").scrollIntoView({ behavior: "smooth" });
    });
  });
}

// ==========================================
// MOCK LICENCE PLATES (PATENTES) DATABASE
// ==========================================
const MOCK_PATENTES = {
  "AB123CD": { brand: "Volkswagen", model: "Gol Trend", year: 2015, engine: "1.6 8V" },
  "AE555QW": { brand: "Toyota", model: "Hilux", year: 2012, engine: "3.0 D-4D" },
  "AD982PP": { brand: "Chevrolet", model: "Corsa", year: 2008, engine: "1.6 8V" },
  "AF345ZX": { brand: "Honda", model: "CG Titan 150", year: 2021, engine: "150cc" },
  "AAA123": { brand: "Chevrolet", model: "Classic", year: 2011, engine: "1.4 8V" },
  "JFA999": { brand: "Toyota", model: "Hilux", year: 2010, engine: "2.5 D-4D" },
  "KOL789": { brand: "Volkswagen", model: "Fox", year: 2013, engine: "1.6 8V" }
};

// ==========================================
// COMPATIBILITY WIDGET MOTOR (WITH PATENTE SUPPORT)
// ==========================================
function initCompatibilityWidget() {
  const brandSelect = document.getElementById("comp-brand");
  const modelSelect = document.getElementById("comp-model");
  const yearSelect = document.getElementById("comp-year");
  const resetBtn = document.getElementById("comp-reset-btn");
  const activeBadge = document.getElementById("comp-active-badge");

  // Tab controls
  const tabVehiculo = document.getElementById("tab-btn-vehiculo");
  const tabPatente = document.getElementById("tab-btn-patente");
  const containerDropdowns = document.getElementById("comp-dropdowns-container");
  const containerPatente = document.getElementById("comp-patente-container");
  
  // Patente elements
  const patenteInput = document.getElementById("comp-patente-input");
  const patenteBtn = document.getElementById("comp-patente-btn");
  const patenteLoader = document.getElementById("comp-patente-loader");

  if (tabVehiculo && tabPatente) {
    // Switch to Vehicle tab
    tabVehiculo.addEventListener("click", () => {
      tabVehiculo.classList.add("active");
      tabPatente.classList.remove("active");
      containerDropdowns.style.display = "block";
      containerPatente.style.display = "none";
    });

    // Switch to Patente tab
    tabPatente.addEventListener("click", () => {
      tabPatente.classList.add("active");
      tabVehiculo.classList.remove("active");
      containerDropdowns.style.display = "none";
      containerPatente.style.display = "block";
    });
  }

  // Brand dropdown triggers model population
  if (brandSelect) {
    brandSelect.addEventListener("change", () => {
      const selectedBrand = brandSelect.value;
      state.filters.compBrand = selectedBrand;
      state.filters.compModel = "";
      state.filters.compYear = "";

      // Clear models and years dropdowns
      modelSelect.innerHTML = `<option value="">-- Modelo --</option>`;
      yearSelect.innerHTML = `<option value="">-- Año --</option>`;
      modelSelect.disabled = true;
      yearSelect.disabled = true;

      if (selectedBrand !== "") {
        const models = VEHICLE_MODELS_MAP[selectedBrand] || [];
        models.forEach(model => {
          modelSelect.innerHTML += `<option value="${model}">${model}</option>`;
        });
        modelSelect.disabled = false;
        resetBtn.style.display = "block";
        activeBadge.style.display = "block";
        activeBadge.textContent = `Filtrando por marca: ${selectedBrand}`;
        activeBadge.style.backgroundColor = "rgba(var(--accent-blue-rgb), 0.1)";
        activeBadge.style.borderColor = "var(--accent-blue)";
        activeBadge.style.color = "var(--accent-blue)";
      } else {
        resetBtn.style.display = "none";
        activeBadge.style.display = "none";
      }

      renderCatalog();
    });
  }

  // Model dropdown triggers year population
  if (modelSelect) {
    modelSelect.addEventListener("change", () => {
      const selectedModel = modelSelect.value;
      state.filters.compModel = selectedModel;
      state.filters.compYear = "";

      yearSelect.innerHTML = `<option value="">-- Año --</option>`;
      yearSelect.disabled = true;

      if (selectedModel !== "") {
        // Populate standard years from 2005 to 2026
        for (let y = 2026; y >= 2005; y--) {
          yearSelect.innerHTML += `<option value="${y}">${y}</option>`;
        }
        yearSelect.disabled = false;
        activeBadge.textContent = `Marca: ${state.filters.compBrand} | Modelo: ${selectedModel}`;
      } else {
        activeBadge.textContent = `Filtrando por marca: ${state.filters.compBrand}`;
      }

      renderCatalog();
    });
  }

  // Year dropdown triggers filter update
  if (yearSelect) {
    yearSelect.addEventListener("change", () => {
      const selectedYear = yearSelect.value;
      state.filters.compYear = selectedYear;

      if (selectedYear !== "") {
        activeBadge.textContent = `Vehículo: ${state.filters.compBrand} ${state.filters.compModel} (${selectedYear})`;
        activeBadge.style.backgroundColor = "rgba(0, 230, 118, 0.15)";
        activeBadge.style.borderColor = "#00e676";
        activeBadge.style.color = "#00e676";
      } else {
        activeBadge.textContent = `Marca: ${state.filters.compBrand} | Modelo: ${state.filters.compModel}`;
        activeBadge.style.backgroundColor = "rgba(var(--accent-blue-rgb), 0.1)";
        activeBadge.style.borderColor = "var(--accent-blue)";
        activeBadge.style.color = "var(--accent-blue)";
      }

      renderCatalog();
    });
  }

  // Patente query click logic
  if (patenteBtn) {
    patenteBtn.addEventListener("click", () => {
      const enteredRaw = patenteInput.value.trim().toUpperCase().replace(/[-\s]/g, "");
      
      if (enteredRaw === "") {
        showToast("Por favor ingrese una patente.");
        return;
      }

      // Validate standard formats
      const isOldFormat = /^[A-Z]{3}\d{3}$/.test(enteredRaw);
      const isNewFormat = /^[A-Z]{2}\d{3}[A-Z]{2}$/.test(enteredRaw);
      const isMotoFormat = /^\d{3}[A-Z]{3}$/.test(enteredRaw) || /^[A-Z]{1}\d{3}[A-Z]{3}$/.test(enteredRaw); // e.g. 123ABC or A123ABC

      if (!isOldFormat && !isNewFormat && !isMotoFormat) {
        showToast("Patente inválida. Formato: AAA123 o AB123CD.");
        return;
      }

      // Simulate registry search
      patenteBtn.disabled = true;
      patenteLoader.style.display = "block";
      resetBtn.style.display = "none";
      activeBadge.style.display = "none";

      setTimeout(() => {
        patenteBtn.disabled = false;
        patenteLoader.style.display = "none";

        let match = MOCK_PATENTES[enteredRaw];
        
        // Fallback: If not explicitly in database, generate a random realistic match based on the plate format
        if (!match) {
          // Motorcycle plate format or random
          if (isMotoFormat || enteredRaw.startsWith("AF") || enteredRaw.startsWith("AE")) {
            // Select a motorcycle or truck randomly
            const choices = [
              { brand: "Honda", model: "CG Titan 150", year: 2019, engine: "150cc" },
              { brand: "Yamaha", model: "YZF-R3", year: 2022, engine: "321cc" },
              { brand: "Toyota", model: "Hilux", year: 2015, engine: "3.0 D-4D" }
            ];
            match = choices[enteredRaw.charCodeAt(0) % choices.length];
          } else {
            // Select an auto randomly
            const choices = [
              { brand: "Volkswagen", model: "Gol Trend", year: 2017, engine: "1.6 8V" },
              { brand: "Chevrolet", model: "Corsa", year: 2010, engine: "1.4 8V" },
              { brand: "Volkswagen", model: "Fox", year: 2012, engine: "1.6 8V" }
            ];
            match = choices[enteredRaw.charCodeAt(0) % choices.length];
          }
        }

        // Apply compatibility filters
        state.filters.compBrand = match.brand;
        state.filters.compModel = match.model;
        state.filters.compYear = match.year.toString();

        // Show results badge
        activeBadge.innerHTML = `
          <div style="font-weight: 800; font-size: 0.8rem; margin-bottom: 2px;">✓ PATENTE ENCONTRADA</div>
          <div>${match.brand} ${match.model} (${match.year})</div>
          <div style="font-size: 0.7rem; opacity: 0.8;">Motor: ${match.engine}</div>
        `;
        activeBadge.style.backgroundColor = "rgba(0, 230, 118, 0.15)";
        activeBadge.style.borderColor = "#00e676";
        activeBadge.style.color = "#00e676";
        activeBadge.style.display = "block";
        resetBtn.style.display = "block";

        showToast(`Vehículo detectado: ${match.brand} ${match.model} ${match.year}`);
        renderCatalog();
      }, 1200);
    });
  }

  // Reset compatibility filters
  if (resetBtn) {
    resetBtn.addEventListener("click", () => {
      if (brandSelect) brandSelect.value = "";
      if (modelSelect) modelSelect.innerHTML = `<option value="">-- Modelo --</option>`;
      if (yearSelect) yearSelect.innerHTML = `<option value="">-- Año --</option>`;
      if (modelSelect) modelSelect.disabled = true;
      if (yearSelect) yearSelect.disabled = true;
      
      if (patenteInput) patenteInput.value = "";

      state.filters.compBrand = "";
      state.filters.compModel = "";
      state.filters.compYear = "";

      resetBtn.style.display = "none";
      activeBadge.style.display = "none";

      renderCatalog();
    });
  }
}


// ==========================================
// BRAND FILTERS RENDERER
// ==========================================
function renderBrandFilters() {
  const brandListContainer = document.getElementById("brand-filter-list");
  const brands = ["todas", ...new Set(PRODUCTS_DATA.map(p => p.brand))];
  
  let html = "";
  brands.forEach(brand => {
    const isSelected = state.filters.brand === brand;
    const label = brand === "todas" ? "Todas las marcas" : brand;
    
    html += `
      <li class="filter-item ${isSelected ? 'active' : ''}" data-brand="${brand}">
        <div class="filter-checkbox"><svg viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/></svg></div>
        ${label}
      </li>
    `;
  });
  
  brandListContainer.innerHTML = html;
  
  const brandItems = brandListContainer.querySelectorAll(".filter-item");
  brandItems.forEach(item => {
    item.addEventListener("click", () => {
      brandItems.forEach(i => i.classList.remove("active"));
      item.classList.add("active");
      state.filters.brand = item.getAttribute("data-brand");
      renderCatalog();
    });
  });
}

// ==========================================
// CATALOG ENGINE (FILTER, SEARCH, SORT)
// ==========================================
function renderCatalog() {
  const gridContainer = document.getElementById("products-grid-container");
  const noResults = document.getElementById("catalog-no-results");
  
  // Filter products
  let filtered = PRODUCTS_DATA.filter(product => {
    // Category match
    if (state.filters.category !== "todos" && product.category !== state.filters.category) {
      return false;
    }
    
    // Vehicle type (subcategory) match
    if (state.filters.vehicle !== "todos" && product.subcategory !== state.filters.vehicle) {
      return false;
    }
    
    // Brand match
    if (state.filters.brand !== "todas" && product.brand !== state.filters.brand) {
      return false;
    }
    
    // Min Price
    if (state.filters.priceMin !== null && product.price < state.filters.priceMin) {
      return false;
    }
    
    // Max Price
    if (state.filters.priceMax !== null && product.price > state.filters.priceMax) {
      return false;
    }
    
    // Text search
    if (state.filters.search.trim() !== "") {
      const q = state.filters.search.toLowerCase();
      const matchName = product.name.toLowerCase().includes(q);
      const matchDesc = product.desc.toLowerCase().includes(q);
      const matchBrand = product.brand.toLowerCase().includes(q);
      if (!matchName && !matchDesc && !matchBrand) {
        return false;
      }
    }

    // VEHICLE COMPATIBILITY FILTER
    if (state.filters.compBrand !== "") {
      // If product has defined compatibilities, we check if one matches
      if (product.compatibilities && product.compatibilities.length > 0) {
        const matchesBrand = product.compatibilities.some(c => c.brand === state.filters.compBrand);
        if (!matchesBrand) return false;

        // If model is selected, match model
        if (state.filters.compModel !== "") {
          const matchesModel = product.compatibilities.some(c => c.brand === state.filters.compBrand && c.model === state.filters.compModel);
          if (!matchesModel) return false;

          // If year is selected, match year range
          if (state.filters.compYear !== "") {
            const yearNum = parseInt(state.filters.compYear);
            const matchesYearRange = product.compatibilities.some(c => 
              c.brand === state.filters.compBrand && 
              c.model === state.filters.compModel && 
              yearNum >= c.yearStart && 
              yearNum <= c.yearEnd
            );
            if (!matchesYearRange) return false;
          }
        }
      } else {
        // If product has empty compatibilities array, it is a Universal item.
        // Universal items fit everything, BUT we match their vehicle category.
        // For example, an alarm for motorcycles (subcategory: motos) should NOT fit when filtering for Volkswagen.
        if (product.subcategory && product.subcategory !== "todos") {
          // If the selected brand is a motorcycle brand, and the product is for motorcycles, we let it pass.
          // Motor brands: Honda, Yamaha, Motomel, Corven.
          const motorBrands = ["Honda", "Yamaha", "Motomel", "Corven"];
          const isMotorBrand = motorBrands.includes(state.filters.compBrand);
          
          if (product.subcategory === "motos" && !isMotorBrand) return false;
          if (product.subcategory === "autos" && isMotorBrand) return false;
          if (product.subcategory === "pickups" && isMotorBrand) return false;
          if (product.subcategory === "camiones" && isMotorBrand) return false;
        }
      }
    }
    
    return true;
  });

  // Sort products
  if (state.sorting === "precio-asc") {
    filtered.sort((a, b) => a.price - b.price);
  } else if (state.sorting === "precio-desc") {
    filtered.sort((a, b) => b.price - a.price);
  } else if (state.sorting === "nombre-asc") {
    filtered.sort((a, b) => a.name.localeCompare(b.name));
  } else {
    filtered.sort((a, b) => {
      if (a.promo && !b.promo) return -1;
      if (!a.promo && b.promo) return 1;
      return b.price - a.price;
    });
  }

  if (filtered.length === 0) {
    gridContainer.style.display = "none";
    noResults.style.display = "block";
    return;
  } else {
    gridContainer.style.display = "grid";
    noResults.style.display = "none";
  }

  let html = "";
  filtered.forEach(product => {
    const formattedPrice = formatCurrency(product.price);
    const oldPriceHtml = product.oldPrice ? `<span class="product-old-price">${formatCurrency(product.oldPrice)}</span>` : "";
    const promoBadge = product.promo ? `<span class="product-badge-promo">Oferta</span>` : "";
    const categoryBadge = product.category === 'motos' ? 'Moto' : product.category === 'vigia-viesa' ? 'Vigia/Viesa' : product.category === 'repuestos' ? 'Repuesto' : 'Accesorios';
    
    html += `
      <article class="product-card glass-panel reveal active" data-id="${product.id}">
        <div class="product-img-wrapper" onclick="openProductDetail(${product.id})">
          <img class="product-img" src="${product.img}" alt="${product.name}" onerror="this.src='https://placehold.co/400x300/12141c/f5f6f9?text=${encodeURIComponent(product.name)}'">
          <div class="product-badges">
            ${promoBadge}
            <span class="badge badge-blue">${categoryBadge}</span>
          </div>
          <button class="product-like-btn" onclick="event.stopPropagation(); toggleLike(${product.id})" aria-label="Agregar a favoritos">
            <svg viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
          </button>
        </div>
        <div class="product-content">
          <span class="product-cat">${product.brand}</span>
          <h3 class="product-title" onclick="openProductDetail(${product.id})">${product.name}</h3>
          <p class="product-desc">${product.desc}</p>
          <div class="product-footer">
            <div class="product-price-box">
              ${oldPriceHtml}
              <span class="product-price">${formattedPrice}</span>
            </div>
            <button class="product-add-cart-btn" onclick="addToCart(${product.id})" aria-label="Añadir al carrito">
              <svg viewBox="0 0 24 24"><path d="M11 9h2V6h3V4h-3V1h-2v3H8v2h3v3zm-4 9c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2zm10 0c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2 2-.9 2-2-.9-2-2-2zm-9.83-6.25l.03-.12.9-1.63h7.45c.75 0 1.41-.41 1.75-1.03l3.8-6.9-1.73-1.02-3.8 6.9H8.1L7 6.27l-.03-.02-1-2.1H1v2h2l3.6 7.59-1.35 2.45c-.16.28-.25.61-.25.96 0 1.1.9 2 2 2h12v-2H7.42c-.13 0-.25-.11-.25-.25z"/></svg>
            </button>
          </div>
        </div>
      </article>
    `;
  });
  
  gridContainer.innerHTML = html;
}

function setCatalogCategory(category) {
  state.filters.category = category;
  
  const sidebarItems = document.querySelectorAll("#category-filter-list .filter-item");
  sidebarItems.forEach(item => {
    item.classList.remove("active");
    if (item.getAttribute("data-value") === category) {
      item.classList.add("active");
    }
  });

  const vehicleSec = document.getElementById("vehicle-filter-section");
  if (category === "repuestos" || category === "todos") {
    vehicleSec.style.display = "block";
  } else {
    vehicleSec.style.display = "none";
    state.filters.vehicle = "todos";
    document.querySelectorAll("#vehicle-filter-list .filter-item").forEach(i => {
      i.classList.remove("active");
      if (i.getAttribute("data-vehicle") === "todos") i.classList.add("active");
    });
  }
  
  renderCatalog();
}

// Export setting category for footer links
window.catalogApp = {
  setCategory: (category) => {
    setCatalogCategory(category);
    setTimeout(() => {
      document.getElementById("catalogo").scrollIntoView({ behavior: "smooth" });
    }, 100);
  }
};

// ==========================================
// CART FUNCTIONALITIES & CALCULATIONS
// ==========================================
function loadCartFromStorage() {
  const saved = localStorage.getItem("albarracin-cart");
  if (saved) {
    try {
      state.cart = JSON.parse(saved);
    } catch (e) {
      state.cart = [];
    }
  }
  updateCartUI();
}

function saveCartToStorage() {
  localStorage.setItem("albarracin-cart", JSON.stringify(state.cart));
  updateCartUI();
}

function addToCart(productId, qty = 1) {
  const existing = state.cart.find(item => item.id === productId);
  if (existing) {
    existing.quantity += qty;
  } else {
    const product = PRODUCTS_DATA.find(p => p.id === productId);
    if (product) {
      state.cart.push({
        id: product.id,
        name: product.name,
        price: product.price,
        img: product.img,
        quantity: qty
      });
    }
  }
  saveCartToStorage();
  
  const badge = document.getElementById("cart-counter");
  badge.style.transform = "scale(1.3)";
  setTimeout(() => {
    badge.style.transform = "scale(1)";
  }, 300);

  openCartDrawer();
}

function updateCartQuantity(productId, delta) {
  const item = state.cart.find(i => i.id === productId);
  if (item) {
    item.quantity += delta;
    if (item.quantity <= 0) {
      removeFromCart(productId);
      return;
    }
  }
  saveCartToStorage();
}

function removeFromCart(productId) {
  state.cart = state.cart.filter(item => item.id !== productId);
  saveCartToStorage();
}

function updateCartUI() {
  const counter = document.getElementById("cart-counter");
  const cartList = document.getElementById("cart-items-list");
  const summaryBox = document.getElementById("cart-summary-box");
  
  const totalItems = state.cart.reduce((sum, item) => sum + item.quantity, 0);
  counter.textContent = totalItems;
  
  if (state.cart.length === 0) {
    cartList.innerHTML = `
      <div class="cart-empty-state">
        <svg class="cart-empty-icon" viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z"/></svg>
        <h3 class="cart-empty-title">Tu carrito está vacío</h3>
        <p class="cart-empty-desc">Explora el catálogo y añade repuestos o accesorios para verlos aquí.</p>
      </div>
    `;
    summaryBox.style.display = "none";
    return;
  }
  
  summaryBox.style.display = "flex";
  
  const subtotal = state.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  document.getElementById("cart-subtotal-price").textContent = formatCurrency(subtotal);
  document.getElementById("cart-total-price").textContent = formatCurrency(subtotal);
  
  let html = "";
  state.cart.forEach(item => {
    html += `
      <div class="cart-item">
        <div class="cart-item-img-wrapper">
          <img class="cart-item-img" src="${item.img}" alt="${item.name}" onerror="this.src='https://placehold.co/100x100/12141c/f5f6f9?text=Repuesto'">
        </div>
        <div class="cart-item-info">
          <h4 class="cart-item-name">${item.name}</h4>
          <div class="cart-item-details">
            <span class="cart-item-price">${formatCurrency(item.price)}</span>
            <div class="cart-qty-control">
              <button class="cart-qty-btn" onclick="updateCartQuantity(${item.id}, -1)">
                <svg viewBox="0 0 24 24"><path d="M19 13H5v-2h14v2z"/></svg>
              </button>
              <span class="cart-qty-val">${item.quantity}</span>
              <button class="cart-qty-btn" onclick="updateCartQuantity(${item.id}, 1)">
                <svg viewBox="0 0 24 24"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
              </button>
            </div>
            <button class="cart-item-remove-btn" onclick="removeFromCart(${item.id})" aria-label="Eliminar item">
              <svg viewBox="0 0 24 24"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
            </button>
          </div>
        </div>
      </div>
    `;
  });
  cartList.innerHTML = html;
}

function openCartDrawer() {
  document.getElementById("cart-drawer-panel").classList.add("open");
  document.getElementById("cart-drawer-overlay").classList.add("open");
}

function closeCartDrawer() {
  document.getElementById("cart-drawer-panel").classList.remove("open");
  document.getElementById("cart-drawer-overlay").classList.remove("open");
}

// ==========================================
// MODAL: PRODUCT DETAIL VIEW WITH ML & COMPATIBILITY
// ==========================================
function openProductDetail(productId) {
  const product = PRODUCTS_DATA.find(p => p.id === productId);
  if (!product) return;
  
  const modal = document.getElementById("product-detail-modal");
  const modalContent = document.getElementById("modal-product-detail-content");
  
  const formattedPrice = formatCurrency(product.price);
  const oldPriceHtml = product.oldPrice ? `<span class="detail-old-price">${formatCurrency(product.oldPrice)}</span>` : "";
  
  // Checking active compatibility to display validation badge in modal
  let compatibilityBadgeHtml = "";
  if (state.filters.compBrand !== "") {
    let matches = false;
    if (!product.compatibilities || product.compatibilities.length === 0) {
      matches = true; // Universal products are compatible
    } else {
      matches = product.compatibilities.some(c => {
        if (c.brand !== state.filters.compBrand) return false;
        if (state.filters.compModel !== "" && c.model !== state.filters.compModel) return false;
        if (state.filters.compYear !== "") {
          const y = parseInt(state.filters.compYear);
          if (y < c.yearStart || y > c.yearEnd) return false;
        }
        return true;
      });
    }

    if (matches) {
      compatibilityBadgeHtml = `
        <div style="background: rgba(0, 230, 118, 0.12); border: 1px solid #00e676; padding: 10px; border-radius: 8px; font-size: 0.85rem; color: #00e676; display: flex; align-items: center; gap: 8px; margin-bottom: 15px; font-weight: 600;">
          <svg viewBox="0 0 24 24" style="width: 18px; height: 18px; fill: currentColor;"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/></svg>
          Compatible con tu ${state.filters.compBrand} ${state.filters.compModel} ${state.filters.compYear ? `(${state.filters.compYear})` : ""}
        </div>
      `;
    }
  }

  // Render specs table
  let specsHtml = "";
  for (const [key, value] of Object.entries(product.specs)) {
    specsHtml += `
      <tr>
        <td class="detail-specs-label">${key}</td>
        <td class="detail-specs-val">${value}</td>
      </tr>
    `;
  }
  
  const tableContent = specsHtml !== "" ? `
    <table class="detail-specs-table">
      <tbody>${specsHtml}</tbody>
    </table>
  ` : "";
  
  modalContent.innerHTML = `
    <div class="detail-img-box">
      <img class="detail-img" src="${product.img}" alt="${product.name}" onerror="this.src='https://placehold.co/600x600/12141c/f5f6f9?text=${encodeURIComponent(product.name)}'">
    </div>
    <div class="detail-info-box">
      <div>
        <span class="detail-cat">${product.brand}</span>
        <h2 class="detail-title">${product.name}</h2>
        <div class="detail-price-box">
          ${oldPriceHtml}
          <span class="detail-price">${formattedPrice}</span>
        </div>
      </div>
      
      ${compatibilityBadgeHtml}
      
      <p class="detail-desc">${product.desc}</p>
      
      ${tableContent}
      
      <div style="background: var(--bg-tertiary); padding: 12px; border-radius: 8px; font-size: 0.8rem; border: 1px solid var(--glass-border); line-height: 1.4; color: var(--text-secondary);">
        💡 <strong>¿Cómo comprar?</strong> Podés agregarlo al carrito y retirarlo en nuestro local en <strong>Pellegrini 1320 (Chabás)</strong> abonando sin comisión, o solicitar envío a domicilio coordinando por WhatsApp.
      </div>
      
      <div class="detail-actions" style="flex-wrap: wrap; gap: 10px;">
        <div class="detail-qty" style="height: 48px;">
          <button class="detail-qty-btn" id="modal-qty-minus">
            <svg viewBox="0 0 24 24"><path d="M19 13H5v-2h14v2z"/></svg>
          </button>
          <span class="detail-qty-val" id="modal-qty-val">1</span>
          <button class="detail-qty-btn" id="modal-qty-plus">
            <svg viewBox="0 0 24 24"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
          </button>
        </div>
        <button class="btn btn-primary detail-add-btn" id="modal-add-to-cart-btn" style="height: 48px;">
          <svg viewBox="0 0 24 24" style="width: 20px; height: 20px; fill: currentColor;"><path d="M11 9h2V6h3V4h-3V1h-2v3H8v2h3v3zm-4 9c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2zm10 0c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2 2-.9 2-2-.9-2-2-2zm-9.83-6.25l.03-.12.9-1.63h7.45c.75 0 1.41-.41 1.75-1.03l3.8-6.9-1.73-1.02-3.8 6.9H8.1L7 6.27l-.03-.02-1-2.1H1v2h2l3.6 7.59-1.35 2.45c-.16.28-.25.61-.25.96 0 1.1.9 2 2 2h12v-2H7.42c-.13 0-.25-.11-.25-.25z"/></svg>
          Comprar Directo (WhatsApp)
        </button>
      </div>
    </div>
  `;
  
  let currentQty = 1;
  const qtyVal = document.getElementById("modal-qty-val");
  
  document.getElementById("modal-qty-minus").addEventListener("click", () => {
    if (currentQty > 1) {
      currentQty--;
      qtyVal.textContent = currentQty;
    }
  });
  
  document.getElementById("modal-qty-plus").addEventListener("click", () => {
    currentQty++;
    qtyVal.textContent = currentQty;
  });
  
  document.getElementById("modal-add-to-cart-btn").addEventListener("click", () => {
    addToCart(product.id, currentQty);
    closeProductDetailModal();
  });
  
  modal.classList.add("open");
}

function closeProductDetailModal() {
  document.getElementById("product-detail-modal").classList.remove("open");
}

function toggleLike(productId) {
  let favs = JSON.parse(localStorage.getItem("albarracin-favs") || "[]");
  if (favs.includes(productId)) {
    favs = favs.filter(id => id !== productId);
  } else {
    favs.push(productId);
  }
  localStorage.setItem("albarracin-favs", JSON.stringify(favs));
  
  const p = PRODUCTS_DATA.find(p => p.id === productId);
  showToast(favs.includes(productId) ? `Añadido a favoritos: ${p.name}` : `Quitado de favoritos: ${p.name}`);
}

// ==========================================
// FORM CHECKOUT & BOOKING (WHATSAPP INTEGRATION)
// ==========================================
function handleCartCheckout() {
  const name = document.getElementById("checkout-name").value.trim();
  const phone = document.getElementById("checkout-phone").value.trim();
  const delivery = document.getElementById("checkout-delivery").value;
  const payment = document.getElementById("checkout-payment").value;
  
  if (name === "" || phone === "") {
    showToast("Por favor completa los campos obligatorios de contacto.");
    return;
  }
  
  const deliveryText = delivery === "retiro" ? "Retiro en Local (Pellegrini 1320, Chabás)" : "Envío a Domicilio (A coordinar)";
  const paymentText = payment === "efectivo" ? "Efectivo / Transferencia" : "Tarjeta de Crédito / Débito";
  
  let msg = `*Hola Albarracín - Motos y Repuestos!*\n`;
  msg += `Quiero consultar / reservar los siguientes productos de la web:\n\n`;
  msg += `*Cliente:* ${name}\n`;
  msg += `*WhatsApp:* ${phone}\n`;
  msg += `*Entrega:* ${deliveryText}\n`;
  msg += `*Forma de pago:* ${paymentText}\n\n`;
  msg += `*Detalle del Pedido:*\n`;
  
  let total = 0;
  state.cart.forEach(item => {
    const itemTotal = item.price * item.quantity;
    total += itemTotal;
    msg += `• ${item.quantity}x ${item.name} (${formatCurrency(item.price)} c/u) = *${formatCurrency(itemTotal)}*\n`;
  });
  
  msg += `\n*Total Estimado:* ${formatCurrency(total)}\n\n`;
  msg += `Quedo a la espera de su confirmación para coordinar el retiro/envío. ¡Gracias!`;
  
  const whatsappUrl = `https://wa.me/5493464685338?text=${encodeURIComponent(msg)}`;
  window.open(whatsappUrl, "_blank");
}

function handleWorkshopBooking(event) {
  event.preventDefault();
  
  const name = document.getElementById("booking-name").value.trim();
  const phone = document.getElementById("booking-phone").value.trim();
  const vehicle = document.getElementById("booking-vehicle").value;
  const service = document.getElementById("booking-service").value;
  const notes = document.getElementById("booking-notes").value.trim();
  
  const vehiclesMap = {
    moto: "Motocicleta",
    auto: "Automóvil",
    pickup: "Pick-up / 4x4",
    camion: "Camión / Acoplado",
    agricola: "Maquinaria Agrícola"
  };
  
  const servicesMap = {
    "vigia-motor": "Instalación/Service Vigia Protector de Motor",
    "vigia-neumaticos": "Instalación/Service Calibrador Neumáticos",
    "viesa-climatizador": "Instalación/Service Climatizador Viesa",
    "taller-electricidad": "Electricidad en General / Baterías",
    "alarma-cierre": "Instalación de Alarma / Cierre Centralizado",
    "otro": "Otro Diagnóstico / Consulta"
  };
  
  let msg = `*Hola Albarracín! Quisiera solicitar un turno para el Taller:*\n\n`;
  msg += `*Cliente:* ${name}\n`;
  msg += `*WhatsApp:* ${phone}\n`;
  msg += `*Vehículo:* ${vehiclesMap[vehicle] || vehicle}\n`;
  msg += `*Servicio:* ${servicesMap[service] || service}\n`;
  
  if (notes !== "") {
    msg += `\n*Detalles del Vehículo y Consulta:*\n_${notes}_\n`;
  }
  
  msg += `\nQuedo a la espera de la confirmación de fecha y hora disponible. ¡Muchas gracias!`;
  
  const whatsappUrl = `https://wa.me/5493464685338?text=${encodeURIComponent(msg)}`;
  window.open(whatsappUrl, "_blank");
}

// ==========================================
// UI EVENT BINDINGS
// ==========================================
function bindUIEvents() {
  document.getElementById("theme-btn").addEventListener("click", toggleTheme);
  document.getElementById("cart-trigger-btn").addEventListener("click", openCartDrawer);
  document.getElementById("cart-close-btn").addEventListener("click", closeCartDrawer);
  document.getElementById("cart-drawer-overlay").addEventListener("click", closeCartDrawer);
  
  const categoryItems = document.querySelectorAll("#category-filter-list .filter-item");
  categoryItems.forEach(item => {
    item.addEventListener("click", () => {
      categoryItems.forEach(i => i.classList.remove("active"));
      item.classList.add("active");
      const val = item.getAttribute("data-value");
      setCatalogCategory(val);
    });
  });

  const vehicleItems = document.querySelectorAll("#vehicle-filter-list .filter-item");
  vehicleItems.forEach(item => {
    item.addEventListener("click", () => {
      vehicleItems.forEach(i => i.classList.remove("active"));
      item.classList.add("active");
      state.filters.vehicle = item.getAttribute("data-vehicle");
      renderCatalog();
    });
  });

  const priceMinInput = document.getElementById("price-min");
  const priceMaxInput = document.getElementById("price-max");
  
  const handlePriceChange = () => {
    const minVal = parseFloat(priceMinInput.value);
    const maxVal = parseFloat(priceMaxInput.value);
    
    state.filters.priceMin = !isNaN(minVal) ? minVal : null;
    state.filters.priceMax = !isNaN(maxVal) ? maxVal : null;
    renderCatalog();
  };
  
  priceMinInput.addEventListener("input", handlePriceChange);
  priceMaxInput.addEventListener("input", handlePriceChange);
  
  const searchBar = document.getElementById("catalog-search");
  searchBar.addEventListener("input", () => {
    state.filters.search = searchBar.value;
    renderCatalog();
  });

  const sortSelect = document.getElementById("catalog-sort");
  sortSelect.addEventListener("change", () => {
    state.sorting = sortSelect.value;
    renderCatalog();
  });

  document.getElementById("modal-close-btn").addEventListener("click", closeProductDetailModal);
  document.getElementById("modal-backdrop-btn").addEventListener("click", closeProductDetailModal);
  document.getElementById("cart-checkout-btn").addEventListener("click", handleCartCheckout);
  document.getElementById("booking-form-element").addEventListener("submit", handleWorkshopBooking);

  const openFiltersBtn = document.getElementById("open-filters-btn");
  const closeFiltersBtn = document.getElementById("close-filters-btn");
  const catalogAside = document.getElementById("catalog-aside");
  const filtersOverlay = document.getElementById("filters-overlay");

  if (openFiltersBtn && catalogAside && filtersOverlay) {
    openFiltersBtn.addEventListener("click", () => {
      catalogAside.classList.add("open");
      filtersOverlay.classList.add("open");
    });
  }

  if (closeFiltersBtn && catalogAside && filtersOverlay) {
    closeFiltersBtn.addEventListener("click", () => {
      catalogAside.classList.remove("open");
      filtersOverlay.classList.remove("open");
    });
  }

  if (filtersOverlay && catalogAside) {
    filtersOverlay.addEventListener("click", () => {
      catalogAside.classList.remove("open");
      filtersOverlay.classList.remove("open");
    });
  }
}

// ==========================================
// HELPERS
// ==========================================
function formatCurrency(value) {
  return new Intl.NumberFormat("es-AR", {
    style: "currency",
    currency: "ARS",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(value);
}

function showToast(message) {
  const toast = document.createElement("div");
  toast.className = "glass-panel";
  toast.style.position = "fixed";
  toast.style.bottom = "20px";
  toast.style.left = "50%";
  toast.style.transform = "translateX(-50%) translateY(100px)";
  toast.style.padding = "12px 24px";
  toast.style.zIndex = "1300";
  toast.style.color = "var(--text-primary)";
  toast.style.border = "1px solid var(--accent-orange)";
  toast.style.boxShadow = "var(--neon-orange-shadow)";
  toast.style.transition = "transform 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275)";
  toast.style.fontSize = "0.95rem";
  toast.style.fontWeight = "600";
  toast.style.textAlign = "center";
  toast.style.backdropFilter = "blur(12px)";
  toast.style.borderRadius = "var(--border-radius-sm)";
  
  toast.textContent = message;
  document.body.appendChild(toast);
  
  setTimeout(() => {
    toast.style.transform = "translateX(-50%) translateY(0)";
  }, 100);
  
  setTimeout(() => {
    toast.style.transform = "translateX(-50%) translateY(100px)";
    setTimeout(() => {
      toast.remove();
    }, 400);
  }, 3500);
}
